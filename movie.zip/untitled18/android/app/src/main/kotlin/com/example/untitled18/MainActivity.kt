package com.example.untitled18

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
