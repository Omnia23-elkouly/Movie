import '../app color.dart';
import 'package:flutter/material.dart';


const apiKey='cc334bf2b960f38ca7240c398f2f4e42';
const KBackgroundColor=AppColors.backgroundDarkColor;
const imageUrl="https://image.tmdb.org/t/p/w500";


