import 'package:untitled18/Api/Api.dart';

class MovieStore {
  final String name;
  final String image;

  MovieStore({required this.name, required this.image, required Api api});
}